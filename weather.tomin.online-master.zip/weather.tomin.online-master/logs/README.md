Your Slim Framework application's log files will be written to this directory.
